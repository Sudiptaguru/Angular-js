import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // title = 'app';
  // displayVal = '';

  // title = 'For loop';
  // title = 'Nested For loop';
  title = 'Style Binding';
  // users = [
  //   {
  //     name: 'Ram',
  //     phone: '1234567802',
  //     socialAccounts: ['facebook', 'insta', 'gmail'],
  //   },
  //   {
  //     name: 'Shyam',
  //     phone: '123456781',
  //     socialAccounts: ['youtube', 'facebook', 'gmail'],
  //   },
  //   {
  //     name: 'Sudipta',
  //     phone: '12345678',
  //     socialAccounts: ['yahoo', 'insta', 'gmail'],
  //   },
  // ];
  // users = ['Ram', 'Shyam', 'Sudipta'];
  // userDetails = [
  //   { name: 'Ram', email: 'ram@gmail.com', phone: '1234567802' },
  //   { name: 'Shyam', email: 'shyam@gmail.com', phone: '123456781' },
  //   { name: 'Sudipta', email: 'sudipta@gmail.com', phone: '12345678' },
  // ];
  // show = true;
  // show = false;
  // show = 'yes';
  color = 'blue';
  bgColor = 'green';
  // color = 'vv';
  updateColor() {
    this.color = 'green';
    this.bgColor = 'red';
  }
}

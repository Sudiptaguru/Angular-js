import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // title = 'app';
  // displayVal = '';

  title = 'For loop';
  users = ['Ram', 'Shyam', 'Sudipta'];
  userDetails = [
    { name: 'Ram', email: 'ram@gmail.com', phone: '1234567802' },
    { name: 'Shyam', email: 'shyam@gmail.com', phone: '123456781' },
    { name: 'Sudipta', email: 'sudipta@gmail.com', phone: '12345678' },
  ];
  // show = true;
  // show = false;
  // show = 'yes';
  // color = 'green';
  // color = 'vv';
}

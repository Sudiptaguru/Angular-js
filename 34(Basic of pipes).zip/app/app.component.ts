import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Basic of pipes';
  today = Date();
  capString(item: string) {
    return item.toUpperCase();
  }
  // data = 20
  // data:{name:string,phn:number}=name:'Sudipta',phn:123

  // getData(item:{name:string,phn:number})
  // {
  //   if(typeof item === "number")
  //   {
  //     return item*20;
  //   }
  // }

  // getData(item:number| string)
  // {
  //   if(typeof item === "number")
  //   {
  //     return item*20;
  //   }
  // }

  // getData(item:number| boolean)
  // {
  //   if(typeof item === "number")
  //   {
  //     return item*20;
  //   }
  // }

  // getData(item:number)
  // {
  //   return item*20;
  // }

  // getItem()
  // {
  //   this.getData(20);
  // }
}

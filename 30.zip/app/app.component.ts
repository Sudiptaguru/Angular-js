import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Send Data child to parent component';
  data = 'x';
  // userDetails = [
  //   { name: 'Sudipta Guru', email: 'sudipta@gmail.com' },
  //   { name: 'Shyam Das', email: 'shyam@gmail.com' },
  //   { name: 'Ram Das', email: 'ram@gmail.com' },
  // ];
  updateData(item: string) {
    console.warn(item);
    this.data = item;
  }
  // data = 10;
  // updateChild() {
  //   // this.data = Math.random();
  //   this.data = Math.floor(Math.random() * 10);
  // }
  list: any[] = [];
  addTask(item: string) {
    this.list.push({ id: this.list.length, name: item });
    // console.warn(item);
    console.warn(this.list);
  }
  removeTask(id: number) {
    console.warn(id);
    this.list = this.list.filter((item) => item.id !== id);
  }
  // display = false;
  display = true;
  toggle() {
    // this.display = false;
    this.display = !this.display;
  }
  // userData: any = {};
  // getData(data: any)
}

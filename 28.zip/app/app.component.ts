import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Toggle element';
  data = 10;
  updateChild() {
    // this.data = Math.random();
    this.data = Math.floor(Math.random() * 10);
  }
  list: any[] = [];
  addTask(item: string) {
    this.list.push({ id: this.list.length, name: item });
    // console.warn(item);
    console.warn(this.list);
  }
  removeTask(id: number) {
    console.warn(id);
    this.list = this.list.filter((item) => item.id !== id);
  }
  // display = false;
  display = true;
  toggle() {
    // this.display = false;
    this.display = !this.display;
  }
  // userData: any = {};
  // getData(data: any)
}

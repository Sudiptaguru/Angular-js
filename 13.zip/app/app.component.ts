import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // title = 'app';
  // displayVal = '';

  title = 'Counter with Angular';
  count = 0;
  counter(type: string) {
    type === 'add' ? this.count++ : this.count--;
    // this.count++;
  }
}

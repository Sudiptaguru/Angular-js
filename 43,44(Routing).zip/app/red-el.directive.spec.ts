import { RedElDirective } from './red-el.directive';

describe('RedElDirective', () => {
  it('should create an instance', () => {
    const directive = new RedElDirective();
    expect(directive).toBeTruthy();
  });
});

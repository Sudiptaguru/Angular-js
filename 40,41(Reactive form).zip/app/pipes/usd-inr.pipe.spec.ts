import { UsdInrPipe } from './usd-inr.pipe';

describe('UsdInrPipe', () => {
  it('create an instance', () => {
    const pipe = new UsdInrPipe();
    expect(pipe).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Toggle element';
  // display = false;
  display = true;
  toggle() {
    // this.display = false;
    this.display = !this.display;
  }
  // userData: any = {};
  // getData(data: any)
}

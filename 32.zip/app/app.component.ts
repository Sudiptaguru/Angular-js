import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Two way binding';
  // getVal(item: any) {
  getVal(item: HTMLInputElement) {
    console.warn(item);
  }
}
